<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shopify_Converter extends Model
{
    //
}
