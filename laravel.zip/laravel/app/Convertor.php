<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Convertor extends Model
{
    //
    protected $fillable = [
        'id'
    ];

}
